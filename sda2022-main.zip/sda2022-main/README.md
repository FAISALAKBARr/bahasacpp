# Praktikum Struktur Data dan Algoritma 2022

Silakan untuk mempelajari materi dari modul yang telah disediakan oleh asisten dengan cara menelusuri tiap-tiap folder pada source code (klik tombol **View code** terlebih dahulu apabila menggunakan handphone) dan membuka file bacaan berformat **.md** dan source code berformat **.cpp**. Selamat belajar ^_^

Asisten pengajar:

- Christopher Digno Mardhika Danneswara (M0520020)
- Michael Raditya Krisnadhi (M0520047)
- Setia Mukti Azizah (M0520074)
- Aditya Aulia Al-Azizi (M0519006)
